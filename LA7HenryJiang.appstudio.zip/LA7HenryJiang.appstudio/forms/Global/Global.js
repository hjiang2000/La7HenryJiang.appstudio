//global variables for other forms
let req = ""
let query = ""
let results = ""
let pw = "Odie6343!"
let netID = "kes97391"
let allCustomerData = []